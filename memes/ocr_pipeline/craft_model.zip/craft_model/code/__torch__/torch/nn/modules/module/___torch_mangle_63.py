op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv : __torch__.torch.nn.modules.module.___torch_mangle_62.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_63.Module,
    input: Tensor) -> Tensor:
    return (self.conv).forward(input, )
