op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["29"] = __torch__.torch.nn.modules.module.___torch_mangle_32.Module
  __annotations__["30"] = __torch__.torch.nn.modules.module.___torch_mangle_33.Module
  __annotations__["31"] = __torch__.torch.nn.modules.module.___torch_mangle_34.Module
  __annotations__["32"] = __torch__.torch.nn.modules.module.___torch_mangle_35.Module
  __annotations__["33"] = __torch__.torch.nn.modules.module.___torch_mangle_36.Module
  __annotations__["34"] = __torch__.torch.nn.modules.module.___torch_mangle_37.Module
  __annotations__["35"] = __torch__.torch.nn.modules.module.___torch_mangle_38.Module
  __annotations__["36"] = __torch__.torch.nn.modules.module.___torch_mangle_39.Module
  __annotations__["37"] = __torch__.torch.nn.modules.module.___torch_mangle_40.Module
  __annotations__["38"] = __torch__.torch.nn.modules.module.___torch_mangle_41.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_42.Module,
    argument_1: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    _0 = getattr(self, "38")
    _1 = getattr(self, "37")
    _2 = getattr(self, "36")
    _3 = getattr(self, "35")
    _4 = getattr(self, "34")
    _5 = getattr(self, "33")
    _6 = getattr(self, "32")
    _7 = getattr(self, "31")
    _8 = getattr(self, "30")
    _9 = (getattr(self, "29")).forward(argument_1, )
    _10 = (_6).forward((_7).forward((_8).forward(_9, ), ), )
    _11 = (_3).forward((_4).forward((_5).forward(_10, ), ), )
    _12 = (_0).forward((_1).forward((_2).forward(_11, ), ), )
    return (_12, _9, _9, _9, _9, _9)
