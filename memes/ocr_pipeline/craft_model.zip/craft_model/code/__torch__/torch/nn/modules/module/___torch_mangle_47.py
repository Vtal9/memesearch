op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  slice1 : __torch__.torch.nn.modules.module.___torch_mangle_12.Module
  slice2 : __torch__.torch.nn.modules.module.___torch_mangle_20.Module
  slice3 : __torch__.torch.nn.modules.module.___torch_mangle_31.Module
  slice4 : __torch__.torch.nn.modules.module.___torch_mangle_42.Module
  slice5 : __torch__.torch.nn.modules.module.___torch_mangle_46.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_47.Module,
    input: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    _0 = self.slice5
    _1 = self.slice4
    _2 = self.slice3
    _3 = (self.slice2).forward((self.slice1).forward(input, ), )
    _4, _5, _6, _7, _8, _9, = _3
    _10, _11, _12, _13, _14, _15, = (_2).forward(_4, )
    _16, _17, _18, _19, _20, _21, = (_1).forward(_10, )
    _22 = ((_0).forward(_16, ), _16, _17, _18, _19, _20, _21, _11, _12, _13, _14, _15, _5, _6, _7, _8, _9)
    return _22
