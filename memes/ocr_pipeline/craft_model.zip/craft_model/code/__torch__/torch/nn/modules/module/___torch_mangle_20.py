op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["12"] = __torch__.torch.nn.modules.module.___torch_mangle_13.Module
  __annotations__["13"] = __torch__.torch.nn.modules.module.___torch_mangle_14.Module
  __annotations__["14"] = __torch__.torch.nn.modules.module.___torch_mangle_15.Module
  __annotations__["15"] = __torch__.torch.nn.modules.module.___torch_mangle_16.Module
  __annotations__["16"] = __torch__.torch.nn.modules.module.___torch_mangle_17.Module
  __annotations__["17"] = __torch__.torch.nn.modules.module.___torch_mangle_18.Module
  __annotations__["18"] = __torch__.torch.nn.modules.module.___torch_mangle_19.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_20.Module,
    argument_1: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    _0 = getattr(self, "18")
    _1 = getattr(self, "17")
    _2 = getattr(self, "16")
    _3 = getattr(self, "15")
    _4 = getattr(self, "14")
    _5 = getattr(self, "13")
    _6 = (getattr(self, "12")).forward(argument_1, )
    _7 = (_3).forward((_4).forward((_5).forward(_6, ), ), )
    _8 = (_0).forward((_1).forward((_2).forward(_7, ), ), )
    return (_8, _6, _6, _6, _6, _6)
