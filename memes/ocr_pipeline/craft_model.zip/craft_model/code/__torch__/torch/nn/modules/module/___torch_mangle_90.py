op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  basenet : __torch__.torch.nn.modules.module.___torch_mangle_47.Module
  upconv1 : __torch__.torch.nn.modules.module.___torch_mangle_55.Module
  upconv2 : __torch__.torch.nn.modules.module.___torch_mangle_63.Module
  upconv3 : __torch__.torch.nn.modules.module.___torch_mangle_71.Module
  upconv4 : __torch__.torch.nn.modules.module.___torch_mangle_79.Module
  conv_cls : __torch__.torch.nn.modules.module.___torch_mangle_89.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_90.Module,
    input: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = self.conv_cls
    _1 = self.upconv4
    _2 = self.upconv3
    _3 = self.upconv2
    _4 = self.upconv1
    _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, = (self.basenet).forward(input, )
    input0 = torch.cat([_5, _6], 1)
    _22 = ops.prim.NumToTensor(torch.size(_9, 2))
    _23 = ops.prim.NumToTensor(torch.size(_10, 3))
    y = torch.upsample_bilinear2d((_4).forward(input0, ), [int(_22), int(_23)], False)
    input1 = torch.cat([y, _11], 1)
    _24 = ops.prim.NumToTensor(torch.size(_14, 2))
    _25 = ops.prim.NumToTensor(torch.size(_15, 3))
    y0 = torch.upsample_bilinear2d((_3).forward(input1, ), [int(_24), int(_25)], False)
    input2 = torch.cat([y0, _16], 1)
    _26 = ops.prim.NumToTensor(torch.size(_19, 2))
    _27 = ops.prim.NumToTensor(torch.size(_20, 3))
    y1 = torch.upsample_bilinear2d((_2).forward(input2, ), [int(_26), int(_27)], False)
    input3 = torch.cat([y1, _21], 1)
    _28 = (_1).forward(input3, )
    _29 = torch.permute((_0).forward(_28, ), [0, 2, 3, 1])
    return (_29, _28)
