op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["19"] = __torch__.torch.nn.modules.module.___torch_mangle_21.Module
  __annotations__["20"] = __torch__.torch.nn.modules.module.___torch_mangle_22.Module
  __annotations__["21"] = __torch__.torch.nn.modules.module.___torch_mangle_23.Module
  __annotations__["22"] = __torch__.torch.nn.modules.module.___torch_mangle_24.Module
  __annotations__["23"] = __torch__.torch.nn.modules.module.___torch_mangle_25.Module
  __annotations__["24"] = __torch__.torch.nn.modules.module.___torch_mangle_26.Module
  __annotations__["25"] = __torch__.torch.nn.modules.module.___torch_mangle_27.Module
  __annotations__["26"] = __torch__.torch.nn.modules.module.___torch_mangle_28.Module
  __annotations__["27"] = __torch__.torch.nn.modules.module.___torch_mangle_29.Module
  __annotations__["28"] = __torch__.torch.nn.modules.module.___torch_mangle_30.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_31.Module,
    argument_1: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    _0 = getattr(self, "28")
    _1 = getattr(self, "27")
    _2 = getattr(self, "26")
    _3 = getattr(self, "25")
    _4 = getattr(self, "24")
    _5 = getattr(self, "23")
    _6 = getattr(self, "22")
    _7 = getattr(self, "21")
    _8 = getattr(self, "20")
    _9 = (getattr(self, "19")).forward(argument_1, )
    _10 = (_6).forward((_7).forward((_8).forward(_9, ), ), )
    _11 = (_3).forward((_4).forward((_5).forward(_10, ), ), )
    _12 = (_0).forward((_1).forward((_2).forward(_11, ), ), )
    return (_12, _9, _9, _9, _9, _9)
